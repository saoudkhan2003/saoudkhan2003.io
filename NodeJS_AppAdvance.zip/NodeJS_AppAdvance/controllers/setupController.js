var Tasks = require('../models/tasksModel');

module.exports = function(app) {
    
   app.get('/api/setupTodos', function(req, res) {
       
       // seed database
       var starterTasks = [
           {
               username: 'saoud',
               todo: 'Learn NodeJS',
               isDone: false,
               hasAttachment: false
           },
           {
               username: 'saoud',
               todo: 'Learn Express',
               isDone: false,
               hasAttachment: false
           },
           {
               username: 'saoud',
               todo: 'Learn MongoDB',
               isDone: false,
               hasAttachment: false
           }
       ];
       Tasks.create(starterTasks, function(err, results) {
           res.send(results);
       }); 
   });
    
}