var configValue = require('./confiugration');

module.exports = {
    
    getDbConnectionString: function() {
        return 'mongodb:// ' + configValue.user + ':' + 
        configValue.pwd + 
        '@ds153869.mlab.com:53869/node-tasks';
    }
    
}
