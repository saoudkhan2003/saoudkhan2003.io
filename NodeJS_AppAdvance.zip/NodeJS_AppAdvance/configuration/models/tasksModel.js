var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var tasksSchema = new Schema({
    username: String,
    todo: String,
    isDone: Boolean,
    hasAttachment: Boolean
});

var Tasks = mongoose.model('Tasks', tasksSchema);

module.exports = Tasks;